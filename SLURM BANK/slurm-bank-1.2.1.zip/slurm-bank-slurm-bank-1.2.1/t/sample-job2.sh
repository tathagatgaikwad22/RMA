#!/bin/bash

#SBATCH -N 32
#SBATCH -c 8
#SBATCH -t 4-00:00:00

echo "HELLO WORLD"
