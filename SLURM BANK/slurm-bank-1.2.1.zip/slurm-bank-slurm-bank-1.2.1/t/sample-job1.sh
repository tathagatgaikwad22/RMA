#!/bin/bash

#SBATCH -n 32
#SBATCH -t 4-00:00:00

echo "HELLO WORLD"
